/*
 * Building.cpp
 *
 *  Created on: Mar 30, 2016
 *      Author: claudio
 */

#include "Building.h"

