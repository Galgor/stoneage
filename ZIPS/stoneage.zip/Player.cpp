/*
 * Player.cpp
 *
 *  Created on: Mar 30, 2016
 *      Author: claudio
 */

#include "Player.h"

Player::Player() {
	// TODO Auto-generated constructor stub

}

Player::~Player() {
	// TODO Auto-generated destructor stub
}

