/*
 * Move.cpp
 *
 *  Created on: Mar 29, 2016
 *      Author: claudio
 */

#include "Move.h"

int Move::idCounter = 0;

Move::Move() {
	// TODO Auto-generated constructor stub
}

Move::~Move() {
	// TODO Auto-generated destructor stub
}

